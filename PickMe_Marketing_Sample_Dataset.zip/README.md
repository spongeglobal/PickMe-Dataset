
# PickMe Rides – Synthetic Marketing & Operations Dataset (Aug 2024 – Jul 2025)

This dataset is **synthetic** and created for Strategic Marketing MSc students to build a Power BI dashboard for customer acquisition, retention, and campaign performance.

## Files
- `dim_customer.csv` – Customer profile & acquisition info
- `dim_driver.csv` – Driver attributes
- `dim_campaign.csv` – Marketing campaign metadata
- `fact_campaign_spend.csv` – Daily campaign spend, impressions, clicks
- `fact_rides.csv` – Ride-level transactions with pricing, discounts, attribution flags
- `dim_date.csv` – Calendar table for date intelligence

## Keys & Relationships (Star Schema)
- `fact_rides.customer_id` → `dim_customer.customer_id`
- `fact_rides.driver_id` → `dim_driver.driver_id`
- `fact_rides.attributed_campaign_id` → `dim_campaign.campaign_id` (many rides to one campaign)
- `dim_customer.acquisition_campaign_id` → `dim_campaign.campaign_id` (optional)
- `fact_campaign_spend.campaign_id` → `dim_campaign.campaign_id`
- `fact_campaign_spend.date` → `dim_date.date`; `fact_rides.request_datetime` should relate to `dim_date.date` via a derived `request_date`

## Suggested Data Types
- Dates: `signup_date`, `driver_signup_date`, `start_date`, `end_date`, `date`, `request_datetime`
- Currency (LKR): `fare_amount_lkr`, `discount_amount_lkr`, `net_fare_lkr`, `platform_fee_lkr`, `driver_earning_lkr`, `spend`

## Notes
- **Attribution**: `attributed_campaign_id` stores a simple last-click attribution (first ride uses acquisition campaign when available; later rides have a chance to be attributed if a campaign is active).
- **First Ride**: `is_first_ride` = true on the first completed ride per customer.
- **Churn**: For analysis, define churn as **no ride in last 60 days** (create a DAX measure).
